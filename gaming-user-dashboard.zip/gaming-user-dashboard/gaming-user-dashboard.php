<?php
/**
 * Plugin Name: Gaming User Dashboard
 * Description: Adds a gaming-style user dashboard rendered via shortcode [gaming_user_dashboard]. Logged-in users can view and update their email and view Steam Listings via the existing [scx_user_listings] shortcode.
 * Version: 1.0.0
 * Author: Senior WP Dev
 * Text Domain: gaming-user-dashboard
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'GUD_Plugin' ) ) {

	class GUD_Plugin {

		/**
		 * Initialize plugin.
		 */
		public static function init() {
			// Register autoload or includes.
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-gud-verification-cpt.php';
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-gud-verification.php';
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-gud-shortcode.php';

			// Initialize admin CPT and frontend shortcode manager.
			GUD_Verification_CPT::get_instance();
			GUD_Shortcode::get_instance();
		}
	}
}

GUD_Plugin::init();
