<?php
/**
 * Identity verification form handling.
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'GUD_Verification' ) ) :

class GUD_Verification {

	/**
	 * Singleton instance.
	 *
	 * @var GUD_Verification|null
	 */
	protected static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return GUD_Verification
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Handle form submission and return flash HTML.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	public function handle_submission( $user_id ) {
		if ( ! isset( $_POST['gud_verify_identity'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return '';
		}

		$nonce_field = isset( $_POST['gud_verify_identity_nonce'] ) ? wp_unslash( $_POST['gud_verify_identity_nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce_field, 'gud_verify_identity_action' ) ) {
			return '<div class="gud-error">' . esc_html__( 'بررسی امنیتی ناموفق بود. لطفاً دوباره تلاش کنید.', 'gaming-user-dashboard' ) . '</div>';
		}

		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return '<div class="gud-error">' . esc_html__( 'شما اجازه ویرایش این حساب را ندارید.', 'gaming-user-dashboard' ) . '</div>';
		}


		$current_status = (string) get_user_meta( $user_id, 'gud_verification_status', true );
		if ( in_array( $current_status, array( 'pending', 'approved' ), true ) ) {
			return '<div class="gud-info">' . esc_html__( 'فرم شما در حال بررسی/تایید است و امکان ویرایش ندارد.', 'gaming-user-dashboard' ) . '</div>';
		}

		$full_name_raw      = isset( $_POST['gud_full_name'] ) ? wp_unslash( $_POST['gud_full_name'] ) : '';
		$mobile_raw         = isset( $_POST['gud_mobile'] ) ? wp_unslash( $_POST['gud_mobile'] ) : '';
		$accepted_rules_raw = isset( $_POST['gud_accept_rules'] ) ? wp_unslash( $_POST['gud_accept_rules'] ) : '';

		$full_name      = sanitize_text_field( $full_name_raw );
		$mobile         = preg_replace( '/[^0-9]/', '', (string) $mobile_raw );
		$accepted_rules = ( '1' === $accepted_rules_raw );

		$gas_mobile       = (string) get_user_meta( $user_id, 'gas_mobile', true );
		$gas_mobile_clean = preg_replace( '/[^0-9]/', '', $gas_mobile );
		if ( ! empty( $gas_mobile_clean ) ) {
			$mobile = $gas_mobile_clean;
		}

		$errors = $this->validate_fields( $full_name, $mobile, $accepted_rules );
		$errors = array_merge( $errors, $this->validate_uploads() );

		if ( ! empty( $errors ) ) {
			return '<div class="gud-error">' . esc_html( implode( ' ', $errors ) ) . '</div>';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$created_attachments = array();
		$id_card_ids         = $this->upload_id_cards( 'gud_id_cards', $created_attachments, $errors );
		$pledge_id           = $this->upload_single_image( 'gud_pledge_file', $created_attachments, $errors, esc_html__( 'تصویر تعهدنامه', 'gaming-user-dashboard' ) );

		if ( ! empty( $errors ) ) {
			$this->cleanup_attachments( $created_attachments );
			return '<div class="gud-error">' . esc_html( implode( ' ', $errors ) ) . '</div>';
		}

		update_user_meta( $user_id, 'gud_verification_full_name', $full_name );
		update_user_meta( $user_id, 'gud_verification_mobile', $mobile );
		update_user_meta( $user_id, 'gud_verification_id_cards', $id_card_ids );
		update_user_meta( $user_id, 'gud_verification_pledge', $pledge_id );
		update_user_meta( $user_id, 'gud_verification_rules_accepted', 1 );
		update_user_meta( $user_id, 'gud_verification_status', 'pending' );
		update_user_meta( $user_id, 'gud_verification_rejection_reason', '' );
		update_user_meta( $user_id, 'gud_verification_submitted_at', current_time( 'mysql' ) );

		if ( class_exists( 'GUD_Verification_CPT' ) ) {
			$submission_post_id = GUD_Verification_CPT::get_instance()->create_submission_post(
				array(
					'user_id'   => $user_id,
					'full_name' => $full_name,
					'mobile'    => $mobile,
					'id_cards'  => $id_card_ids,
					'pledge_id' => $pledge_id,
				)
			);

			if ( $submission_post_id > 0 ) {
				update_user_meta( $user_id, 'gud_verification_post_id', $submission_post_id );
			}
		}

		return '<div class="gud-success gud-toast-success" data-gud-toast="success">' . esc_html__( 'فرم با موفقیت ارسال شد', 'gaming-user-dashboard' ) . '</div>';
	}

	/**
	 * Get prefilled form data.
	 *
	 * @param int $user_id User ID.
	 * @return array<string,mixed>
	 */
	public function get_form_data( $user_id ) {
		$gas_mobile = (string) get_user_meta( $user_id, 'gas_mobile', true );
		$gas_mobile = preg_replace( '/[^0-9]/', '', $gas_mobile );
		$saved      = (string) get_user_meta( $user_id, 'gud_verification_mobile', true );

		$status      = (string) get_user_meta( $user_id, 'gud_verification_status', true );
		$id_card_ids = (array) get_user_meta( $user_id, 'gud_verification_id_cards', true );
		$pledge_id   = absint( get_user_meta( $user_id, 'gud_verification_pledge', true ) );

		if ( empty( $status ) ) {
			$status = 'none';
		}

		$status_labels = array(
			'none'     => __( 'ثبت نشده', 'gaming-user-dashboard' ),
			'pending'  => __( 'در حال بررسی', 'gaming-user-dashboard' ),
			'approved' => __( 'تایید شده', 'gaming-user-dashboard' ),
			'rejected' => __( 'رد شده', 'gaming-user-dashboard' ),
		);

		$is_editable = in_array( $status, array( 'none', 'rejected' ), true );

		return array(
			'full_name'      => (string) get_user_meta( $user_id, 'gud_verification_full_name', true ),
			'mobile'         => ! empty( $gas_mobile ) ? $gas_mobile : $saved,
			'mobile_locked'  => ! empty( $gas_mobile ) || ! $is_editable,
			'status'         => $status,
			'status_label'   => isset( $status_labels[ $status ] ) ? $status_labels[ $status ] : $status_labels['none'],
			'is_editable'    => $is_editable,
			'id_card_ids'    => array_map( 'absint', $id_card_ids ),
			'pledge_id'      => $pledge_id,
			'rules_accepted'   => (bool) get_user_meta( $user_id, 'gud_verification_rules_accepted', true ),
			'rejection_reason' => (string) get_user_meta( $user_id, 'gud_verification_rejection_reason', true ),
		);
	}

	/**
	 * Validate basic fields.
	 *
	 * @param string $full_name Full name.
	 * @param string $mobile Mobile number.
	 * @param bool   $accepted_rules Accepted rules.
	 * @return array
	 */
	private function validate_fields( $full_name, $mobile, $accepted_rules ) {
		$errors = array();

		$full_name_parts = preg_split( '/\s+/', trim( $full_name ) );
		if ( ! is_array( $full_name_parts ) || count( $full_name_parts ) < 2 ) {
			$errors[] = esc_html__( 'نام و نام خانوادگی باید حداقل شامل دو کلمه با فاصله باشد.', 'gaming-user-dashboard' );
		} else {
			$first_name = isset( $full_name_parts[0] ) ? $full_name_parts[0] : '';
			$last_name  = isset( $full_name_parts[1] ) ? $full_name_parts[1] : '';
			if ( mb_strlen( $first_name ) < 3 || mb_strlen( $last_name ) < 3 ) {
				$errors[] = esc_html__( 'نام و نام خانوادگی باید هر کدام حداقل ۳ حرف باشند.', 'gaming-user-dashboard' );
			}
		}

		if ( 11 !== strlen( $mobile ) || 0 !== strpos( $mobile, '09' ) ) {
			$errors[] = esc_html__( 'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.', 'gaming-user-dashboard' );
		}

		if ( ! $accepted_rules ) {
			$errors[] = esc_html__( 'برای ارسال فرم باید قوانین سایت را بپذیرید.', 'gaming-user-dashboard' );
		}

		return $errors;
	}

	/**
	 * Validate upload fields.
	 *
	 * @return array
	 */
	private function validate_uploads() {
		$errors          = array();
		$max_upload_size = 5 * MB_IN_BYTES;

		if ( empty( $_FILES['gud_id_cards'] ) || empty( $_FILES['gud_id_cards']['name'] ) || ! is_array( $_FILES['gud_id_cards']['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$errors[] = esc_html__( 'آپلود تصویر کارت ملی الزامی است.', 'gaming-user-dashboard' );
		} else {
			$names = array_filter( array_map( 'sanitize_file_name', wp_unslash( $_FILES['gud_id_cards']['name'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
			if ( count( $names ) !== 2 ) {
				$errors[] = esc_html__( 'برای کارت ملی دقیقاً 2 تصویر (پشت و رو) ارسال کنید.', 'gaming-user-dashboard' );
			}

			$sizes = isset( $_FILES['gud_id_cards']['size'] ) && is_array( $_FILES['gud_id_cards']['size'] ) ? $_FILES['gud_id_cards']['size'] : array(); // phpcs:ignore WordPress.Security.NonceVerification
			foreach ( $sizes as $size ) {
				if ( absint( $size ) > $max_upload_size ) {
					$errors[] = esc_html__( 'هر تصویر کارت ملی باید حداکثر 5 مگابایت باشد.', 'gaming-user-dashboard' );
					break;
				}
			}
		}

		if ( empty( $_FILES['gud_pledge_file'] ) || empty( $_FILES['gud_pledge_file']['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$errors[] = esc_html__( 'آپلود تصویر تعهدنامه الزامی است.', 'gaming-user-dashboard' );
		} else {
			$size = isset( $_FILES['gud_pledge_file']['size'] ) ? absint( $_FILES['gud_pledge_file']['size'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
			if ( $size > $max_upload_size ) {
				$errors[] = esc_html__( 'تصویر تعهدنامه باید حداکثر 5 مگابایت باشد.', 'gaming-user-dashboard' );
			}
		}

		return $errors;
	}

	/**
	 * Upload ID card images.
	 *
	 * @param string $field_name Input field.
	 * @param array  $created_attachments Created attachments list.
	 * @param array  $errors Errors list.
	 * @return array
	 */
	private function upload_id_cards( $field_name, &$created_attachments, &$errors ) {
		$uploaded = array();
		$files    = $_FILES[ $field_name ]; // phpcs:ignore WordPress.Security.NonceVerification
		$total    = count( $files['name'] );

		for ( $i = 0; $i < $total; $i++ ) {
			if ( empty( $files['name'][ $i ] ) ) {
				continue;
			}

			$file = array(
				'name'     => sanitize_file_name( wp_unslash( $files['name'][ $i ] ) ),
				'type'     => isset( $files['type'][ $i ] ) ? sanitize_text_field( wp_unslash( $files['type'][ $i ] ) ) : '',
				'tmp_name' => isset( $files['tmp_name'][ $i ] ) ? wp_unslash( $files['tmp_name'][ $i ] ) : '',
				'error'    => isset( $files['error'][ $i ] ) ? absint( $files['error'][ $i ] ) : 0,
				'size'     => isset( $files['size'][ $i ] ) ? absint( $files['size'][ $i ] ) : 0,
			);

			$attachment_id = media_handle_sideload( $file, 0 );
			if ( is_wp_error( $attachment_id ) || ! wp_attachment_is_image( $attachment_id ) ) {
				if ( ! is_wp_error( $attachment_id ) ) {
					wp_delete_attachment( $attachment_id, true );
				}
				$errors[] = esc_html__( 'آپلود تصویر کارت ملی ناموفق بود. فقط تصویر معتبر بارگذاری کنید.', 'gaming-user-dashboard' );
				break;
			}

			$uploaded[]             = absint( $attachment_id );
			$created_attachments[]  = absint( $attachment_id );
		}

		if ( count( $uploaded ) !== 2 && empty( $errors ) ) {
			$errors[] = esc_html__( 'آپلود تصاویر کارت ملی کامل نیست.', 'gaming-user-dashboard' );
		}

		return $uploaded;
	}

	/**
	 * Upload single image.
	 *
	 * @param string $field_name Field name.
	 * @param array  $created_attachments Created attachments.
	 * @param array  $errors Errors.
	 * @param string $label Label.
	 * @return int
	 */
	private function upload_single_image( $field_name, &$created_attachments, &$errors, $label ) {
		$attachment_id = media_handle_upload( $field_name, 0 );
		if ( is_wp_error( $attachment_id ) || ! wp_attachment_is_image( $attachment_id ) ) {
			if ( ! is_wp_error( $attachment_id ) ) {
				wp_delete_attachment( $attachment_id, true );
			}
			$errors[] = sprintf( esc_html__( 'آپلود %s ناموفق بود.', 'gaming-user-dashboard' ), $label );
			return 0;
		}

		$created_attachments[] = absint( $attachment_id );

		return absint( $attachment_id );
	}

	/**
	 * Cleanup attachments.
	 *
	 * @param array $attachment_ids IDs.
	 * @return void
	 */
	private function cleanup_attachments( $attachment_ids ) {
		foreach ( $attachment_ids as $attachment_id ) {
			wp_delete_attachment( absint( $attachment_id ), true );
		}
	}
}

endif;
